// handig object om te gebruiken inplaats van strings

var AppConstants	=	{
	
};
