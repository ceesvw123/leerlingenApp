var app = app || {};

// dit object bevat de functies om studenten op te halen, etc.
// vanuit dit bestand ga je ook je PHP API lastig vallen met de vraag "mag ik alle studenten"


app.studentsModel = Object.create(eventDispatcher);

app.studentsModel.loadStudents = function() {
    // dit is de functie die de studenten ophaalt bij je PHP pagina
    // als de studenten zijn geladen, dan dispatcht hij een event
    // je view (bijvoorbeeld de randomStudentView) moet luisteren naar dit event
    //
    // this.dispatch("CHANGE"); // deze 'dispatch' pas uitvoeren als je studenten JSON is geladen
    var self = this;
    var studentsrequest = new HttpRequest();
    studentsrequest.load("http://localhost:8888/bewijzenmap/year2/periode3/sct/md_sct_3_1/les_5/backend/getStudent.php",
        function(data){
            self.students=data;
            self.dispatch("CHANGE");
           // console.log(data);
        });

};

app.studentsModel.getRandomStudent=function(){
    //console.log(this.student);
    var rdIndex = Math.floor(Math.random() * this.students.length);
    return this.students[rdIndex];
};

app.studentsModel.getAll = function() {
    return this.students;
};

