<?php
/**
 * Created by PhpStorm.
 * User: jorisbulters
 * Date: 22-03-16
 * Time: 14:54
 */

require 'includes/config.php';
require_once 'includes/database.php';