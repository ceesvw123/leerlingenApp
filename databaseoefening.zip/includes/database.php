<?php

$conn = new mysqli($servername, $username, $password, $dbname);