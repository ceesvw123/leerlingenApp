<?php

//require 'js/util/httprequest.js';

require 'includes/config.php';
require_once 'includes/database.php';

$students = array();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM students";
$result = $conn->query($sql);

//echo json_encode($sql);

if ($result->num_rows > 0) {
    while($student = $result->fetch_assoc()) {
        $students[] = array_map('utf8_encode', $student);

    }
} else {
    echo "0 results";
}

$conn->close();

echo json_encode($students);

?>